import { motion } from "framer-motion";

export function Gallery() {
  // Using placeholders for now as per instructions.
  // In a real app, these would come from an API or storage.
  const images = [
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540003212132453/1.png?ex=696e9005&is=696d3e85&hm=c6a352c1d3f9bc0393f6940c31d158ec2b6e5bcd67f7f3b8113355ca54a8d8e7&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540003966976242/2.png?ex=696e9005&is=696d3e85&hm=be721d94954e5685ebf211803aca1c9aa138356b92257949e3f9784f98a56a24&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540004478685205/3.png?ex=696e9005&is=696d3e85&hm=45982080134aca8aedef10e01e1a3e7cdde490781dc0110265dc068aa4311464&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540005011488798/4.png?ex=696e9005&is=696d3e85&hm=f5ff4ac5c5693f0e8c8704f25914251c32bd5f83d24c06cacb0af9605ae08950&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540005728583844/5.jpg?ex=696e9006&is=696d3e86&hm=a8dcad72396d7dddfed05b7e897564e50d1c58289649d9249be3ca4eb284d7ab&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540006332825660/6.png?ex=696e9006&is=696d3e86&hm=1a8eb55beb37abc46c63a281d4e380d2197df134564030f7fad3c500d6bc3966&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540833805963509/7.jpg?ex=696e90cb&is=696d3f4b&hm=31ee19513cdafe7874e06484aea043284dd80c8b39e10492373f63c24c666d7a&",
    "https://cdn.discordapp.com/attachments/1462223138178732215/1462540860054048995/8.png?ex=696e90d1&is=696d3f51&hm=0e0b554136f1ee49badf797404f735031e8d5175f89369a4dc83d8ccc4eb8506&",
  ];

  return (
    <section className="py-12 border-t border-white/5 mt-12">
      <div className="flex items-center gap-4 mb-8">
        <div className="h-8 w-1 bg-accent rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)]" />
        <h2 className="text-2xl font-bold font-body text-white">תמונות קהל</h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        {images.map((src, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="relative aspect-video rounded-xl overflow-hidden group cursor-pointer border border-white/5 hover:border-accent/50 transition-all duration-300"
          >
            {/* HTML Comment for Stock Images */}
            {/* Stock images from Unsplash depicting sports fans/stadium atmosphere */}
            <img 
              src={src} 
              alt={`Gallery image ${i + 1}`} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <span className="text-white font-bold tracking-widest text-sm border border-white/30 px-4 py-1 rounded-full backdrop-blur-md">
                VIEW
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
