import { useProducts, useCart } from "@/hooks/use-shop";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Plus } from "lucide-react";

export function ProductGrid() {
  const { data: products, isLoading } = useProducts();
  const { addToCart } = useCart();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="h-48 bg-card/30 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  const staffProducts = products?.filter(p => p.category === 'staff') || [];
  const leadershipProducts = products?.filter(p => p.category === 'leadership') || [];

  return (
    <div className="space-y-16">
      {/* Staff Ranks Section */}
      <ProductSection 
        title="צוות" 
        products={staffProducts} 
        onAdd={addToCart} 
      />

      {/* Leadership Roles Section */}
      <ProductSection 
        title="הנהגה" 
        products={leadershipProducts} 
        onAdd={addToCart} 
      />
    </div>
  );
}

function ProductSection({ 
  title, 
  products, 
  onAdd
}: { 
  title: string; 
  products: Product[]; 
  onAdd: (p: Product) => void; 
}) {
  if (products.length === 0) return null;

  return (
    <section className="mb-16">
      <h2 className="text-sm uppercase tracking-widest text-white/40 mb-8 border-b border-white/10 pb-2">{title}</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-px bg-white/10 border border-white/10">
        {products.map((product) => (
          <div
            key={product.id}
            className="bg-black p-6 md:p-8 hover:bg-white/[0.02] transition-colors"
          >
            <div className="flex flex-col h-full">
              <div className="mb-6 md:mb-8">
                <h3 className="text-base md:text-lg font-medium text-white mb-2">
                  {product.name}
                </h3>
                {product.description && (
                  <p className="text-xs md:text-sm text-white/50 leading-relaxed">
                    {product.description}
                  </p>
                )}
              </div>
              
              <div className="flex items-center justify-between mt-auto gap-4">
                <span className="text-base md:text-lg font-medium whitespace-nowrap">₪{product.price}</span>
                <Button 
                  size="sm" 
                  onClick={() => onAdd(product)}
                  variant="outline"
                  className="rounded-none border-white/20 hover:bg-white hover:text-black transition-all text-xs md:text-sm px-3 md:px-4"
                >
                  ADD TO CART
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
