import { useCart, useCreateOrder, useTeams } from "@/hooks/use-shop";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, Trash2, CheckCircle, ShieldAlert } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function Cart() {
  const { items, selectedTeamId, setTeam, removeFromCart, getTotal, clearCart } = useCart();
  const { data: teams, isLoading: isLoadingTeams } = useTeams();
  const createOrder = useCreateOrder();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const total = getTotal();

  const handleCheckout = async (method: 'paypal' | 'kashkash') => {
    if (!selectedTeamId && items.some(i => i.category === 'leadership')) {
      toast({
        title: "שגיאה",
        description: "חובה לבחור קבוצה עבור תפקידי הנהגה",
        variant: "destructive",
      });
      return;
    }
    
    if (items.length === 0) {
      toast({
        title: "העגלה ריקה",
        description: "נא להוסיף מוצרים לפני ביצוע הזמנה",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await createOrder.mutateAsync({
        teamId: selectedTeamId || undefined,
        items: items,
        total: total,
      });
      
      const PAYPAL_EMAIL = "omrimf11@gmail.com";
      const note = `Order for ${items.map(i => i.name).join(', ')}`;

      if (method === 'paypal') {
        window.open(`https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=${PAYPAL_EMAIL}&amount=${total}&currency_code=ILS&item_name=${encodeURIComponent(note)}`, '_blank');
      } else {
        // KashKash placeholder or logic if provided
        toast({
          title: "KashKash Payment",
          description: "Redirecting to KashKash...",
        });
      }

      toast({
        title: "ההזמנה התקבלה בהצלחה!",
        description: "פרטי ההזמנה נשלחו למערכת.",
        className: "bg-green-600 text-white border-none",
      });
      clearCart();
    } catch (error) {
      toast({
        title: "שגיאה בביצוע ההזמנה",
        description: error instanceof Error ? error.message : "נסה שנית מאוחר יותר",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="border border-white/10 p-4 md:p-8">
      <div className="flex items-center justify-between mb-8 md:mb-12">
        <h2 className="text-sm uppercase tracking-widest text-white/40">סל קניה</h2>
        <ShoppingCart className="w-4 h-4 text-white/20" />
      </div>

      <div className="space-y-8 md:space-y-12">
        <section>
          <h3 className="text-xs uppercase tracking-widest text-white/20 mb-4 md:mb-6">בחירת קבוצה</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-1 gap-px bg-white/10 border border-white/10">
            {teams?.map((team) => (
              <button
                key={team.id}
                onClick={() => setTeam(team.id)}
                className={cn(
                  "p-3 md:p-4 text-xs md:text-sm transition-all text-center lg:text-right",
                  selectedTeamId === team.id
                    ? "bg-white text-black"
                    : "bg-black text-white/60 hover:text-white"
                )}
              >
                {team.name}
              </button>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-xs uppercase tracking-widest text-white/20 mb-4 md:mb-6">הזמנה</h3>
          <div className="space-y-3 md:space-y-4">
            {items.length === 0 ? (
              <p className="text-sm text-white/20 py-6 md:py-8 text-center border border-dashed border-white/10">Empty</p>
            ) : (
              items.map((item) => (
                <div key={item.id} className="flex justify-between items-center text-sm">
                  <div className="flex items-center gap-3 md:gap-4">
                    <button onClick={() => removeFromCart(item.id)} className="text-white/20 hover:text-white p-1">×</button>
                    <span>{item.name}</span>
                  </div>
                  <span className="text-white/40 whitespace-nowrap">₪{item.price * item.quantity}</span>
                </div>
              ))
            )}
          </div>
          
          <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-white/10 flex justify-between items-baseline">
            <span className="text-xs uppercase tracking-widest text-white/20">Total</span>
            <span className="text-xl md:text-2xl font-light">₪{total}</span>
          </div>
        </section>

        <div className="space-y-3">
          <Button 
            className="w-full h-12 md:h-14 rounded-none bg-white text-black hover:bg-white/90 font-bold tracking-widest text-sm"
            onClick={() => handleCheckout('paypal')}
            disabled={isSubmitting || items.length === 0}
            data-testid="button-checkout-paypal"
          >
            {isSubmitting ? "PROCESSING" : "PAY WITH PAYPAL"}
          </Button>
          <Button 
            variant="outline"
            className="w-full h-12 md:h-14 rounded-none border-white/10 hover:bg-white hover:text-black font-bold tracking-widest text-sm"
            onClick={() => handleCheckout('kashkash')}
            disabled={isSubmitting || items.length === 0}
            data-testid="button-checkout-kashkash"
          >
            {isSubmitting ? "PROCESSING" : "PAY WITH KASHCASH"}
          </Button>
        </div>
      </div>
    </div>
  );
}
