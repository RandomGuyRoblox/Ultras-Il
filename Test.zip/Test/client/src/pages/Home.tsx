import { ProductGrid } from "@/components/ProductGrid";
import { Cart } from "@/components/Cart";
import { Gallery } from "@/components/Gallery";
import { motion } from "framer-motion";
import { SiDiscord } from "react-icons/si";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 py-6">
        <div className="max-w-6xl mx-auto px-6">
          <h1 className="text-xl font-bold tracking-tighter">ULTRAS IL</h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8 md:py-12" dir="rtl">
        <div className="flex flex-col lg:grid lg:grid-cols-12 gap-8 md:gap-12">
          <div className="lg:col-span-8 order-2 lg:order-1">
            <ProductGrid />
            <Gallery />
            
            <section className="mt-16 md:mt-24 p-6 md:p-12 border border-white/10 bg-white/5 rounded-xl text-center">
              <div className="flex justify-center mb-6">
                <SiDiscord className="w-12 h-12 md:w-16 md:h-16 text-[#5865F2]" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">שרת הדיסקורד שלנו</h2>
              <p className="text-white/60 mb-8 max-w-md mx-auto text-sm md:text-base">
                מוזמנים להצטרף ולקבל תמיכה 24/7
              </p>
              <Button 
                variant="outline" 
                className="h-10 md:h-12 px-6 md:px-8 border-white/20 hover:bg-white hover:text-black transition-all text-sm md:text-base w-full sm:w-auto"
                onClick={() => window.open('https://discord.gg/your-invite', '_blank')}
                data-testid="button-discord-support"
              >
                התחברות
              </Button>
            </section>
          </div>
          <div className="lg:col-span-4 order-1 lg:order-2">
            <Cart />
          </div>
        </div>
      </main>

      <footer className="border-t border-white/10 py-12 text-center text-sm text-white/40">
        © 2024 Ultras IL. All rights reserved.
      </footer>
    </div>
  );
}
