## Packages
framer-motion | For smooth animations and page transitions
zustand | For global cart state management
clsx | For conditional class merging
tailwind-merge | For merging tailwind classes safely

## Notes
The application requires RTL support.
Fonts: 'Heebo' or 'Rubik' for Hebrew text, 'Chakra Petch' or 'Rajdhani' for English headers/gaming vibe.
