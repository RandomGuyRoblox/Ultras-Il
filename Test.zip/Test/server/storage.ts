import { products, teams, orders, type Product, type Team, type InsertOrder, type Order } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getProducts(): Promise<Product[]>;
  getTeams(): Promise<Team[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  seedData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db.insert(orders).values(insertOrder).returning();
    return order;
  }

  async seedData(): Promise<void> {
    const existingProducts = await db.select().from(products);
    if (existingProducts.length === 0) {
      await db.insert(products).values([
        { name: 'הלפר דיסקורד', price: 30, category: 'staff' },
        { name: 'אדמין בצוות', price: 100, category: 'staff' },
        { name: 'איש גדר', price: 75, category: 'leadership' },
        { name: 'ראש אנשי גדר', price: 150, category: 'leadership' },
        { name: 'ראש ארגון', price: 250, category: 'leadership' },
      ]);
    }

    const existingTeams = await db.select().from(teams);
    if (existingTeams.length === 0) {
      await db.insert(teams).values([
        { name: 'ביתר ירושלים' },
        { name: 'מכבי חיפה' },
        { name: 'מכבי תל אביב' },
        { name: 'הפועל באר שבע' },
        { name: 'הפועל תל אביב' },
        { name: 'הפועל ירושלים' },
        { name: 'הפועל פתח תקווה' },
        { name: 'מכבי נתניה' },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
